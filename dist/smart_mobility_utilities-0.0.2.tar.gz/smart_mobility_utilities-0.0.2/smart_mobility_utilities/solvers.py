"""
Solvers for combinatorial problems.
""" 


"""
WORK IN PROGRESS
"""